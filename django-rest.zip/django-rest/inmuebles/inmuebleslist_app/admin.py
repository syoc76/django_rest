from django.contrib import admin
from inmuebleslist_app.models import Inmueble
# Register your models here.
admin.site.register(Inmueble)