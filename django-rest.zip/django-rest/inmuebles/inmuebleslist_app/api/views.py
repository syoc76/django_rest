from rest_framework.response import Response 
from inmuebleslist_app.models import Inmueble
from inmuebleslist_app.api.serializers import InmuebleSerializer
# from rest_framework.decorators import api_view 
from rest_framework import status
#from django.shortcuts import get_object_or_404
from rest_framework.views import APIView

class InmuebleListAV(APIView):
    
    def get(self, request):
        inmuebles = Inmueble.objects.all()
        serializer = InmuebleSerializer(inmuebles, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = InmuebleSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else: 
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class InmuebleDetalleAV(APIView):
    def get(self, request, pk):
        try:
            inmueble = Inmueble.objects.get(pk=pk)
        except Inmueble.DoesNotExist:
            return Response( {'error:', 'inmueble no encontrado'},status=status.HTTP_400_NOT_FOUND)
        serializer = InmuebleSerializer(Inmueble)
        return Response(serializer)
    
    def put(self,request,pk):
        try:
            inmueble = Inmueble.objects.get(pk=pk)
        except Inmueble.DoesNotExist:
            return Response( {'error:', 'inmueble no encontrado'},status=status.HTTP_400_NOT_FOUND)
        
        serializer = InmuebleSerializer(inmueble)
        return Response(serializer.data)
       
       
    def put(self,request,pk):
        try:
            inmueble = Inmueble.objects.get(pk=pk)
        except Inmueble.DoesNotExist:
            return Response( {'error:', 'inmueble no encontrado'},status=status.HTTP_400_NOT_FOUND)
        serializer = InmuebleSerializer(inmueble, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
              return Response( serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
        
    def delete(self, request, pk):
        try:
            inmueble = Inmueble.objects.get(pk=pk)
        except Inmueble.DoesNotExist:
            return Response( {'error:', 'inmueble no encontrado'},status=status.HTTP_400_NOT_FOUND)
        
        inmueble.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
       
       
       
       
       
       
       
       
       
       
        
        
        
        
        
        
        
        
        
        
        
    
        
        
        
        
        
    

# class InmuebleListView(APIView):
#     def get(self, request ):
#         inmuebles = Inmueble.objects.all()
#         serializer = InmuebleSerializer(inmuebles, many=True)
#         return Response(serializer.data)
#     def post(self, request):
#            serializer = InmuebleSerializer(data = request.data)
#            if serializer.is_valid():
#                serializer.save()
#                return Response(serializer.data)
#            else:
#                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# class InmuebleDetailView(APIView):
#     def get(self, request, pk):
#         try:
#             inmueble = Inmueble.objects.get(pk=pk)
#         except Inmueble.DoesNotExist:
#             return Response('{error','Inmueble no encontrado}', status=status.HTTP_400_BAD_REQUEST)
             
#             serializer = InmuebleSerializer(inmueble)
#             return Response(serializer.data)
#     def put(self, request, pk):
#         try:
#             inmueble = Inmueble.objects.get(pk=pk)
#         except Inmueble.DoesNotExist:
#             return Response('{error','Inmueble no encontrado}', status=status.HTTP_400_BAD_REQUEST)
#         serializer = InmuebleSerializer(inmueble, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
#     def delete(self, request, pk):
#         try:
#             inmueble = Inmueble.objects.get(pk=pk)
#         except Inmueble.DoesNotExist:
#             return Response('{error','Inmueble no encontrado}', status=status.HTTP_400_BAD_REQUEST)
#         Inmueble.delete()
#         return Response(status=status.HTTP_204_NO_CONTENT)
        
        
        


# @api_view(['GET','POST'])
# def inmueble_list(request):
#     if request.method == 'GET':    
#         inmuebles = Inmueble.objects.all()
#         serializer = InmuebleSerializer(inmuebles, many=True)
#         return Response(serializer.data)
    
#     elif request.method == 'POST':
#         serializer = InmuebleSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['GET','PUT','DELETE'])
# def inmueble_detalle(request, pk):
#     inmueble = get_object_or_404(Inmueble, pk=pk)
    
#     if request.method == 'GET':
#         try :
#             inmueble = Inmueble.objects.get(pk=pk)
#             serializer = InmuebleSerializer(inmueble)
#             return Response(serializer.data)
#         except Inmueble.DoesNotExist:
#             return Response({'Error' 'El inmueble no existe'}, status=status.HTTP_400__NOT_FOUND)
    
#     elif request.method == 'PUT':
#         serializer = InmuebleSerializer(inmueble, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    
#     elif request.method == 'DELETE':
#         try:
#             inmueble = Inmueble.objects.get(pk=pk)
#             inmueble.delete()
#         except Inmueble.DoesNotExist:
#              return Response('{Error el inmueble no existe}', status=status.HTTP_404_NO_CONTENT)
            
#         return Response(status=status.HTTP_204_NO_CONTENT)
